# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 16:38:37 2019

@author: S41
"""

import pandas as pd
import numpy as np
import FAA as fa
from functools import reduce

class Container():
    pass
def params_work():
    BLpara=Container() #BL模型参数
    GFpara=Container() #高斯滤波参数
    # 参数
    GFpara.W = 120 # 窗口长
    GFpara.period  = [42,100,200] # 三大周期
    GFpara.guassalpha = 10
    GFpara.L_zero = 2^12
    # BL模型参数
    BLpara.CovWindow = 100
    BLpara.ConfiWindow = 12
    BLpara.Tau = 0.1
    BLpara.Lamda = 1
    BLpara.c = 0.1
    BLpara.delta = 1
    return GFpara,BLpara

def three_factors_work(large_asts,sub_asts,data_all_yoy,types,GFpara):
    if large_asts|sub_asts:
        # 提取周期三因子，并滤波大类资产指数
        if len(types)==2:
            resX,resY1,resY2=fa.get_3factors_n_largeasset_filter(data_all_yoy,types,GFpara,False)
        else:
            resX,resY1,resY2,resY3=fa.get_3factors_n_largeasset_filter(data_all_yoy,types,GFpara,False)
        #resX,resY1,resY2,resY3,resY4,resY5=fa.get_3factors_n_largeasset_filter(data_all_yoy,types,GFpara,False)
        # 得到预测值和当期值，用于等下结和beta计算
        X_now,X_pre=fa.filter_predict(resX,GFpara,1) #原版
        X_now-=X_pre

    if large_asts:
        # 大类资产回归
        if len(types)==2:
            Beta,Pv=fa.cal_Beta(resX,resY1,resY2)
            Beta_dif,Pv_dif=fa.cal_Beta_dif(resX,resY1,resY2)
        else:
            Beta,Pv=fa.cal_Beta(resX,resY1,resY2,resY3)
            Beta_dif,Pv_dif=fa.cal_Beta_dif(resX,resY1,resY2,resY3)
        # 每一期用期末值* beta得到大类资产预测值。按顺序排，股债商
        predict_all_Assets=fa.cal_n_diff(X_now,list(Beta),data_all_yoy)

        # 差分模型预测
        predict_all_Assets_dif=fa.cal_n_diff(X_now[1:],list(Beta_dif),data_all_yoy)

    return predict_all_Assets,predict_all_Assets_dif

def three_factors_work2(large_asts,sub_asts,data_all_yoy,types,GFpara):
    if large_asts|sub_asts:
        # 提取周期三因子，并滤波大类资产指数
        resX,resY1,resY2=get_3factors_n_largeasset_filter_2(data_all_yoy,types,GFpara,False)
        # 得到预测值和当期值，用于等下结和beta计算
        X_now,X_pre=fa.filter_predict(resX,GFpara,1) #原版
        X_now-=X_pre

    if large_asts:
        # 大类资产回归
        Beta,Pv=fa.cal_Beta(resX,resY1,resY2)
        Beta_dif,Pv_dif=fa.cal_Beta_dif(resX,resY1,resY2)
        # 每一期用期末值* beta得到大类资产预测值。按顺序排，股债商
        predict_all_Assets=fa.cal_n_diff(X_now,list(Beta),data_all_yoy)

        # 差分模型预测
        predict_all_Assets_dif=fa.cal_n_diff(X_now[1:],list(Beta_dif),data_all_yoy)

    return predict_all_Assets,predict_all_Assets_dif




def signal2weight(predict_all_Assets,predict_all_Assets_dif,data_all_yoy,types):
    ## 二、大类资产之间配置
    RankNum=predict_all_Assets.rank(axis=1,ascending=False)
    # 1.配TOP1
    W_method1={1:1,2:0,3:0}
    Weight_1=RankNum.replace(W_method1).values
    Weight_1=np.column_stack([np.array([Weight_1[:,i]]*len(types[i])).T for i in range(len(types))])
    # 将顺序调整成原始数据的品种顺序
    Weight_1=pd.DataFrame(Weight_1,index=RankNum.index,
                          columns=data_all_yoy.columns[reduce(lambda x,y:x+y,types)]).loc[:,data_all_yoy.columns]

    '''
    # 3.配风险/不风险
    W_method1={1:1,2:0,3:0}
    Weight_3=RankNum.replace(W_method1).values
    Weight_3=np.column_stack([Weight_3[:,i]*len(types[i]) for i in range(len(types))])
    Weight_3=pd.DataFrame(Weight_3,index=RankNum.index,
                          columns=data_all_yoy.columns[reduce(lambda x,y:x+y,types)])
    '''
    ## 差分模型大类
    RankNumDif=predict_all_Assets_dif.rank(axis=1,ascending=False)
    # 1.配TOP1
    W_method1={1:1,2:0,3:0}
    Weight_dif_1=RankNumDif.replace(W_method1).values
    Weight_dif_1=np.column_stack([np.array([Weight_dif_1[:,i]]*len(types[i])).T for i in range(len(types))])
    # 将顺序调整成原始数据的品种顺序
    Weight_dif_1=pd.DataFrame(Weight_dif_1,index=RankNum.index,
                          columns=data_all_yoy.columns[reduce(lambda x,y:x+y,types)]
                          ).loc[:,data_all_yoy.columns]

    return Weight_1,Weight_dif_1,RankNum,RankNumDif

def cal_riskparial_work(data_all_yoy,Weight,RankNum,RankNumDif,types,cov):
    risk_budget_stk=np.array([1/6.]*6)
    risk_budget_combine=np.array([0.1]*6+[0.4])
    norisk_budget=np.array([0.2,0.2,0.2,0.2,0.2])

    res=[]
    if RankNum.shape[1]==3: #这个判断为了说明股票和商品是一起配还是分别
        for day,value in Weight['2010':].iterrows():
            # 取cov
            if RankNum.type2[day]==1: #配商品
                budget=norisk_budget
                covM=cov.loc[day].iloc[6:-1,6:-1]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(np.append(np.array([0]*6),solve),np.array([0]))
            elif RankNum.type1[day]==1: #配风险资产
                budget=risk_budget_stk
                covM=cov.loc[day].iloc[:6,:6]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(solve,np.array([0]*6))
            else:
                solves=np.append(np.array([0]*11),np.array([1]))
            res.append(solves)
    else:
        for day,value in Weight['2010':].iterrows():
            # 取cov
            if RankNum.type2[day]==1: #配债券
                budget=norisk_budget
                covM=cov.loc[day].iloc[6:-1,6:-1]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(np.append(np.array([0]*6),solve),np.array([0]))
            else: #配风险资产
                budget=risk_budget_combine
                covM=cov.loc[day].iloc[[0,1,2,3,4,5,-1],[0,1,2,3,4,5,-1]]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(np.append(solve[:-1],np.array([0]*5)),solve[-1:])
            res.append(solves)
    risk_parial_weight=pd.DataFrame(res,index=Weight.index[-len(res):],columns=Weight.columns)

    res=[]
    if RankNumDif.shape[1]==3: #这个判断为了说明股票和商品是一起配还是分别
        for day,value in Weight['2010':].iterrows():
            # 取cov
            if RankNumDif.type2[day]==1: #配商品
                budget=norisk_budget
                covM=cov.loc[day].iloc[6:-1,6:-1]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(np.append(np.array([0]*6),solve),np.array([0]))
            elif RankNumDif.type1[day]==1: #配风险资产
                budget=risk_budget_stk
                covM=cov.loc[day].iloc[:6,:6]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(solve,np.array([0]*6))
            else:
                solves=np.append(np.array([0]*11),np.array([1]))
            res.append(solves)
    else:
        for day,value in Weight['2010':].iterrows():
            # 取cov
            if RankNumDif.type2[day]==1: #配商品
                budget=norisk_budget
                covM=cov.loc[day].iloc[6:-1,6:-1]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(np.append(np.array([0]*6),solve),np.array([0]))
            else: #配风险资产
                budget=risk_budget_combine
                covM=cov.loc[day].iloc[[0,1,2,3,4,5,-1],[0,1,2,3,4,5,-1]]
                solve,check,ct=fa.risk_budget_model_root(covM,budget,1)
                solves=np.append(np.append(solve[:-1],np.array([0]*5)),solve[-1:])
            res.append(solves)

    risk_parial_weight_dif=pd.DataFrame(res,index=Weight.index[-len(res):],columns=Weight.columns)
    return risk_parial_weight,risk_parial_weight_dif

def daily_backtest(signal,ret_daily):
    w_org=signal.shift(5).dropna()
    w=w_org.reindex(ret_daily.index).fillna(method='bfill')
    S=fa.Strategy(ret_daily,w,delay=0,start_date='2010-6',freq='D')
    s=S.Nv
    s=np.log(s/s.shift(1)).dropna()
    return S,s,w

def VolControl(s,w,decay1,decay2,target_vol,trigger,ret_daily):
    def ewm_2ju(x,decay):
        r_arr=np.array([decay**(41-i) for i in range(40)])
        res=np.sqrt(np.average(x**2,weights=r_arr)*254)
        return res
    s_rv_1=s.rolling(window=40).apply(ewm_2ju,kwargs={'decay':decay1},raw=True)
    s_rv_2=s.rolling(window=40).apply(ewm_2ju,kwargs={'decay':decay2},raw=True)
    s_rv=s_rv_1.copy()
    s_rv[:]=np.where(s_rv_1>s_rv_2,s_rv_1,s_rv_2)
    actualW_tmp=[]
    last_actualW=0
    actualW=s_rv.copy()
    for day,volmax in s_rv.dropna().iteritems():
        if last_actualW==0:
            last_actualW=target_vol/volmax
            continue
        # 找杠杆
        tmp=w.loc[day,'Germany10yr builder']
        max_leverage=1.5 if tmp==0 else 2.0
        # 算theo W
        try:
            theoW=target_vol/volmax
        except:
            print(day,volmax)
            return
        # 判断阈值
        if abs(last_actualW*volmax-target_vol)>trigger:
            actualW.loc[day]=min(max_leverage,theoW)
            last_actualW=min(max_leverage,theoW)
        else:
            actualW.loc[day]=last_actualW
    actualW_tmp.append(actualW)
    actualW1=actualW_tmp[0]
    w_adj=(w.T*actualW1.shift(1)).T.dropna()
    sadj=fa.Strategy(ret_daily,w_adj,delay=0,start_date='2010-7-27',freq='D')
    return sadj





def get_3factors_n_largeasset_filter_2(data_all_yoy,types,GFpara,
                                     predict=False,includeX=True,show_df=False):
    # 在每个时刻，对过去一段窗口期内的数据进行滤波提取三因子，然后再对自己也进行滤波。然后回归
    # 返回值变成array
    W,period,guassalpha=GFpara.W,GFpara.period,GFpara.guassalpha
    resX,resY1,resY2,resY3  =  [],[],[],[]
    for i in range(W,len(data_all_yoy)):
        try:
            # 计算每段X滤波的结果
            tmp = data_all_yoy.iloc[i-W:i] #不包括第i期
            if includeX:
                resX.append( Sumple_sumple3(tmp,types,period = period,guassalpha = guassalpha,
                    W = W))
            tmp1=fa.sumple_c2(tmp.iloc[:,types[0]])
            tmp2=fa.sumple_c2(tmp.iloc[:,types[2]])
            tmp3=np.column_stack((tmp1,tmp2))
            resY1.append( fa.sumple_c2(tmp3))
            resY2.append( fa.sumple_c2(tmp.iloc[:,types[1]]))
        except:
            pass
    '''
    # 这部分是不删除最后一个预测值，用于现实中得到最新的预测
    if predict:
        idx+=1
        tmp = data_all_yoy.iloc[-W:]
        resX[idx] = Sumple_sumple2(tmp,types,period = period,guassalpha = guassalpha,
            W = W)
        resY1[idx] = sumple_c2(tmp.iloc[:,types[0]])
        resY2[idx] = sumple_c2(tmp.iloc[:,types[1]])
        resY3[idx] = sumple_c2(tmp.iloc[:,types[2]])
    '''
    if show_df: #展示dataframe版本
        pass
    resY1=np.array(resY1)
    resY2=np.array(resY2)
    #resY3=np.array(resY3)
    # 新增
    #resY4=np.array(resY4)
    #resY5=np.array(resY5)
    # 新增结束
    if includeX:
        restmp=[x.values for x in resX]
        resX=np.array(restmp)
        return resX,resY1,resY2#,resY3#,resY4,resY5
    else:
        return resY1,resY2,resY3,resY4,resY5

def Sumple_sumple3(df,types,period = [42,100,200],guassalpha = 10,L_zero = 2**12,W = 80,L = 0,i_ter = 100):
    res = pd.DataFrame()
    res2 = pd.DataFrame()
    large_asset_factor = pd.DataFrame()
    for p in period:
        #把df滤波。把所有数据都滤波了
        df1 = fa.gauss_filter_c(df,1,p,guassalpha,L_zero,W+L)
        #根据大类划分，分别进行sumple
        for Type in types:
            large_asset_factor[str(Type)] = fa.sumple_c2(df1[:,Type],i_ter).T[0]
        #将三个大类sumple结果，再sumple
        res2['a'] = fa.sumple_c2(large_asset_factor.iloc[:,[0,2]],i_ter).T[0]
        res2['b']= large_asset_factor.iloc[:,1]
        res['p'+str(p)] = fa.sumple_c2(res2,i_ter).T[0]
    return res
