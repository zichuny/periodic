# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 16:39:38 2019

@author: zp
"""
# In[]
# 三方库
import pandas as pd
import numpy as np
from numpy import ones

# 自编库
import FAA as fa
import pack0607 as pk

# 读取数据
data_all_price = pd.read_csv('month_px.csv',index_col=0)
data_all_price.index = pd.to_datetime(data_all_price.index)
data_all_yoy = np.log(data_all_price/data_all_price.shift(12)).dropna() #同比

# 读取部分参数
GFpara,BLpara=pk.params_work() #需要修改参数去pack中修改

large_asts=True # 大类资产配置，使用合成因子
sub_asts=True # 直接子类资产配置，使用合成因子

# 对资产进行分类
type1,type2,type3  =  [0,1,2,3,4,5],[6,7,8,9,10],[11]
types1  =  [type1,type2,type3] # 集合成list
type1,type2  =  [0,1,2,3,4,5,11],[6,7,8,9,10]
types2  =  [type1,type2] # 集合成list
# In[]

# 周期三因子提取、合成、回归、预测（模块1）和模块4，共6种组合
predict_all_Assets1,predict_all_Assets_dif1=pk.three_factors_work(large_asts,sub_asts,data_all_yoy,types1,GFpara)
predict_all_Assets2,predict_all_Assets_dif2=pk.three_factors_work(large_asts,sub_asts,data_all_yoy,types2,GFpara)
predict_all_Assets3,predict_all_Assets_dif3=pk.three_factors_work2(large_asts,sub_asts,data_all_yoy,types1,GFpara)
# In[]
# 把预测信号转化成权重
Weight_1,Weight_dif_1,RankNum1,RankNumDif1=pk.signal2weight(predict_all_Assets1,predict_all_Assets_dif1,data_all_yoy,types1)
Weight_2,Weight_dif_2,RankNum2,RankNumDif2=pk.signal2weight(predict_all_Assets2,predict_all_Assets_dif2,data_all_yoy,types2)
Weight_3,Weight_dif_3,RankNum3,RankNumDif3=pk.signal2weight(predict_all_Assets3,predict_all_Assets_dif3,data_all_yoy,types2)
# In[] 计算风险平价权重
#
cov_df=pd.read_csv('daily_px.csv',index_col=0)
cov_df.index=pd.to_datetime(cov_df.index)
cov=cov_df.pct_change().shift(1)['2009':].rolling(window=40).cov().dropna()
idx=pd.Series([x[0] for x in cov.index.values])
idx.index=idx.values
cov=cov[idx.isin(data_all_yoy.index).values]

risk_parial_weight1,risk_parial_weight_dif1=pk.cal_riskparial_work(
        data_all_yoy,Weight_1,RankNum1,RankNumDif1,types1,cov)
risk_parial_weight2,risk_parial_weight_dif2=pk.cal_riskparial_work(
        data_all_yoy,Weight_2,RankNum2,RankNumDif2,types2,cov)
risk_parial_weight3,risk_parial_weight_dif3=pk.cal_riskparial_work(
        data_all_yoy,Weight_3,RankNum3,RankNumDif3,types2,cov)
# In[] 生成等权重中间过程变量

# 配置一共12个权重（暂时没有波动率控制）
# 2种等权重
idxlen=Weight_1.shape[0]
eqw1=np.column_stack([ones((idxlen,len(types1[i])))/len(types1[i]) for i in range(len(types1))])
eqw1=pd.DataFrame(eqw1,index=Weight_1.index,
                      columns=data_all_yoy.columns[types1[0]+types1[1]+types1[2]]
                      ).loc[:,data_all_yoy.columns] #最后的loc为了排序
eqw2=np.column_stack([ones((idxlen,len(types2[i])))/len(types2[i]) for i in range(len(types2))])
eqw2=pd.DataFrame(eqw2,index=Weight_1.index,
                      columns=data_all_yoy.columns[types2[0]+types2[1]]
                      ).loc[:,data_all_yoy.columns] #最后的loc为了排序
# In[] 计算配置权重
# 注：这里比如2010-6-30日的权重，是指2010年6月份配置的权重，而非下一期的

# 按照大类资产分类的权重
# 原版 股债商
strategy_w_1_1=Weight_1*eqw1
strategy_w_1_2=Weight_1*risk_parial_weight1
strategy_w_1_3=Weight_dif_1*eqw1
strategy_w_1_4=Weight_dif_1*risk_parial_weight_dif1
# 分类2
strategy_w_2_1=Weight_2*eqw2
strategy_w_2_2=Weight_2*risk_parial_weight2
strategy_w_2_3=Weight_dif_2*eqw2
strategy_w_2_4=Weight_dif_2*risk_parial_weight_dif2
# 分类3
strategy_w_3_1=Weight_3*eqw2
strategy_w_3_2=Weight_3*risk_parial_weight3
strategy_w_3_3=Weight_dif_3*eqw2
strategy_w_3_4=Weight_dif_3*risk_parial_weight_dif3
# In[] 月频率回测

# 生成策略回测——月频率版本。可以不用
ret_all=data_all_price.pct_change()#.dropna()

strategy_1_1=fa.Strategy(ret_all,strategy_w_1_1,delay=5,start_date='2010-6')
strategy_1_2=fa.Strategy(ret_all,strategy_w_1_2,delay=5,start_date='2010-6')
strategy_1_3=fa.Strategy(ret_all,strategy_w_1_3,delay=5,start_date='2010-6')
strategy_1_4=fa.Strategy(ret_all,strategy_w_1_4,delay=5,start_date='2010-6')

strategy_2_1=fa.Strategy(ret_all,strategy_w_2_1,delay=5,start_date='2010-6')
strategy_2_2=fa.Strategy(ret_all,strategy_w_2_2,delay=5,start_date='2010-6')
strategy_2_3=fa.Strategy(ret_all,strategy_w_2_3,delay=5,start_date='2010-6')
strategy_2_4=fa.Strategy(ret_all,strategy_w_2_4,delay=5,start_date='2010-6')

strategy_3_1=fa.Strategy(ret_all,strategy_w_3_1,delay=5,start_date='2010-6')
strategy_3_2=fa.Strategy(ret_all,strategy_w_3_2,delay=5,start_date='2010-6')
strategy_3_3=fa.Strategy(ret_all,strategy_w_3_3,delay=5,start_date='2010-6')
strategy_3_4=fa.Strategy(ret_all,strategy_w_3_4,delay=5,start_date='2010-6')
# In[] 日频率回测

# 生成日度频率的信号权重
ret_daily=pd.read_csv('daily_px.csv',index_col=0)
ret_daily.index=pd.to_datetime(ret_daily.index)
ret_daily=ret_daily.pct_change()['2010-06':'2019-3']

# 生成日度回测.S是回测class，s是对应的日度对数收益率
S_1_1,s_1_1,w_1_1=pk.daily_backtest(strategy_w_1_1,ret_daily)
S_1_2,s_1_2,w_1_2=pk.daily_backtest(strategy_w_1_2,ret_daily)
S_1_3,s_1_3,w_1_3=pk.daily_backtest(strategy_w_1_3,ret_daily)
S_1_4,s_1_4,w_1_4=pk.daily_backtest(strategy_w_1_4,ret_daily)

S_2_1,s_2_1,w_2_1=pk.daily_backtest(strategy_w_2_1,ret_daily)
S_2_2,s_2_2,w_2_2=pk.daily_backtest(strategy_w_2_2,ret_daily)
S_2_3,s_2_3,w_2_3=pk.daily_backtest(strategy_w_2_3,ret_daily)
S_2_4,s_2_4,w_2_4=pk.daily_backtest(strategy_w_2_4,ret_daily)

S_3_1,s_3_1,w_3_1=pk.daily_backtest(strategy_w_3_1,ret_daily)
S_3_2,s_3_2,w_3_2=pk.daily_backtest(strategy_w_3_2,ret_daily)
S_3_3,s_3_3,w_3_3=pk.daily_backtest(strategy_w_3_3,ret_daily)
S_3_4,s_3_4,w_3_4=pk.daily_backtest(strategy_w_3_4,ret_daily)
# In[] 波动率控制

# 波动率控制后的策略
target_vol=0.05 #目标波动率
trigger=0.003 #偏离阈值
decay1=0.97 #指数平均波动率
decay2=0.94 #指数平均波动率

sadj_1_1=pk.VolControl(s_1_1,w_1_1,decay1,decay2,target_vol,trigger,ret_daily)
sadj_1_2=pk.VolControl(s_1_2,w_1_2,decay1,decay2,target_vol,trigger,ret_daily)
sadj_1_3=pk.VolControl(s_1_3,w_1_3,decay1,decay2,target_vol,trigger,ret_daily)
sadj_1_4=pk.VolControl(s_1_4,w_1_4,decay1,decay2,target_vol,trigger,ret_daily)

sadj_2_1=pk.VolControl(s_2_1,w_2_1,decay1,decay2,target_vol,trigger,ret_daily)
sadj_2_2=pk.VolControl(s_2_2,w_2_2,decay1,decay2,target_vol,trigger,ret_daily)
sadj_2_3=pk.VolControl(s_2_3,w_2_3,decay1,decay2,target_vol,trigger,ret_daily)
sadj_2_4=pk.VolControl(s_2_4,w_2_4,decay1,decay2,target_vol,trigger,ret_daily)

sadj_3_1=pk.VolControl(s_3_1,w_3_1,decay1,decay2,target_vol,trigger,ret_daily)
sadj_3_2=pk.VolControl(s_3_2,w_3_2,decay1,decay2,target_vol,trigger,ret_daily)
sadj_3_3=pk.VolControl(s_3_3,w_3_3,decay1,decay2,target_vol,trigger,ret_daily)
sadj_3_4=pk.VolControl(s_3_4,w_3_4,decay1,decay2,target_vol,trigger,ret_daily)
# In[] 波动率控制的日频率回测储存
name_dict1={'1':'原版股债商','2':'大类资产分类2','3':'大类资产分类3'}
name_dict2={'1':'原版三因子+等权','2':'原版三因子+风险平价','3':'差分模型+等权','4':'差分模型+风险平价'}

for i1 in ['1','2','3']:
    for i2 in ['1','2','3','4']:
        writer=pd.ExcelWriter('%s+%s.xlsx'%(name_dict1[i1],name_dict2[i2]))
        locals()['sadj_%s_%s'%(i1,i2)].Indicator.to_excel(writer,'指标统计量')
        locals()['sadj_%s_%s'%(i1,i2)].Nv.to_excel(writer,'净值')
        locals()['sadj_%s_%s'%(i1,i2)].signal.dropna().to_excel(writer,'权重')
        writer.save()
# In[] 无波动率控制的日频率回测储存
name_dict1={'1':'原版股债商','2':'大类资产分类2','3':'大类资产分类3'}
name_dict2={'1':'原版三因子+等权','2':'原版三因子+风险平价','3':'差分模型+等权','4':'差分模型+风险平价'}

for i1 in ['1','2','3']:
    for i2 in ['1','2','3','4']:
        writer=pd.ExcelWriter('%s+%s-无波动率控制.xlsx'%(name_dict1[i1],name_dict2[i2]))
        locals()['S_%s_%s'%(i1,i2)].Indicator.to_excel(writer,'指标统计量')
        locals()['S_%s_%s'%(i1,i2)].Nv.to_excel(writer,'净值')
        locals()['S_%s_%s'%(i1,i2)].signal.dropna().to_excel(writer,'权重')
        writer.save()

# In[] 波动率控制的日频率回测储存-储存到一张表
nv=[]
indi=[]

for i1 in ['1','2','3']:
    for i2 in ['1','2','3','4']:
        tmptmp=locals()['sadj_%s_%s'%(i1,i2)].Nv
        tmptmp.name='%s+%s'%(name_dict1[i1],name_dict2[i2])
        nv.append(tmptmp)
        tmptmp=locals()['sadj_%s_%s'%(i1,i2)].Indicator
        tmptmp.index=['%s+%s'%(name_dict1[i1],name_dict2[i2])]
        indi.append(tmptmp)

nv=pd.concat(nv,axis=1)
nv.index=pd.Index([pd.to_datetime('2010-7-26')]).append(nv.index[1:])
indi=pd.concat(indi)

writer=pd.ExcelWriter('汇总-波动率控制.xlsx')
nv.to_excel(writer,'净值对比')
indi.to_excel(writer,'指标对比')
writer.save()
# In[] 无波动率控制的日频率回测储存-储存到一张表
nv=[]
indi=[]
for i1 in ['1','2','3']:
    for i2 in ['1','2','3','4']:
        tmptmp=locals()['S_%s_%s'%(i1,i2)].Nv
        tmptmp.name='%s+%s'%(name_dict1[i1],name_dict2[i2])
        nv.append(tmptmp)
        tmptmp=locals()['S_%s_%s'%(i1,i2)].Indicator
        tmptmp.index=['%s+%s'%(name_dict1[i1],name_dict2[i2])]
        indi.append(tmptmp)

nv=pd.concat(nv,axis=1)
nv.index=pd.Index([pd.to_datetime('2010-7-26')]).append(nv.index[1:])
indi=pd.concat(indi)

writer=pd.ExcelWriter('汇总-无控制.xlsx')
nv.to_excel(writer,'净值对比')
indi.to_excel(writer,'指标对比')
writer.save()