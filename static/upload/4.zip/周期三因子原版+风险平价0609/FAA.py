# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 15:34:16 2019

@author: S41
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from numpy import conj,diag,real,angle,dot,ones,exp,pi,sqrt,zeros
from scipy.optimize import minimize,root
from scipy.fftpack import hilbert
from numpy.fft import fftshift
import scipy as sc
import copy
from statsmodels.api import OLS,add_constant


def gauss_filter_c(wave,dt = 1,period = 42,guassalfa = 10,L_zero = 2**12,L = 120+0):
    '''
    高斯滤波器
    L_zero :目标补零长度
    L：目标输出长度 如果用于滤波，就是n，也就是和原序列等长；如果用于预测，就要L
    output：目标输出序列
    '''
    #补零
    #df_flg = False
    #if type(wave) == pd.core.frame.DataFrame:
    #    idx = wave.index
    #    df_flg = True
    try:
        m,n = wave.shape
    except:
        #wave = pd.DataFrame(wave)
        #wave = wave.reshape(len(wave),1)
        m,n = wave.shape[0],1
        wave = np.array([wave]).T
    tmp = np.zeros((L_zero-m,n))
    #print(type(wave))
    #print(wave.shape,tmp.shape)
    wave = np.vstack((wave,tmp))
    wave_fft = sc.fft(wave.T,L_zero).T #变换必须横着
    num = np.arange(L_zero)+1
    num_T = L_zero*dt/period+1
    Gauss_win = exp(-guassalfa*(num-num_T)**2/(num_T)**2)
    wave_filter = (wave_fft.T*Gauss_win).T
    if L_zero%2 == 0:
        wave_filter[int(L_zero/2+1):] = conj(wave_filter[int(L_zero/2)-1:0:-1])
    else:
        wave_filter[int((L_zero-1)/2+1):] = conj(wave_filter[int((L_zero-1)/2):0:-1])
    output = real(sc.ifft(wave_filter.T,L_zero)).T
    output = output[:L]
    return output #暂时输出变成array

def sumple_c2( X1, maxiter = 100):
    '''
    sumple算法
    '''
    if len(X1.shape) == 1:
        #print('shape only 1')
        return np.array(X1)
    if X1.shape[1] == 1:
        #print('shape2 only 1')
        return np.array(X1)
    else:
        X = np.array(X1)
        ncor,n = X.shape
        tmps = []
        for i in range(X.shape[1]):
            tmp = X[:,i]-hilbert(X[:,i])*1j
            tmps.append(tmp)
        tmps = np.column_stack(tuple(tmps))
        X = tmps#.round(4)
        weight  =  ones((1,n))
        phase_path = ones((maxiter+1,n))*1j
        angle_path = ones((maxiter+1,n))*1j
        phase_path[0,:] = weight
        angle_path[0,:] = angle(weight) #这里理论上有*180/pi，但是由于init是0
        for i in range(maxiter):
            x  =  X[:ncor,:]
            weight = np.mat(weight)
            tmp = np.array(conj(x*weight.H*ones((1,n))-x*np.mat(diag(conj(weight).A[0]))))
            weight=np.mat(np.mean(tmp*x,axis=0))#.round(4)
            #weight  =  np.mean(conj(dot(dot(x,conj(weight.T)),ones((1,n))) - dot(x ,diag(conj(weight[0].T))))*x,axis = 0).round(4)
            # 转化成矩阵？
            weight=np.array(sqrt(n/(weight*weight.H))*weight)
            #weight  =  dot(np.sqrt(n / dot(weight,conj(weight))), weight)#.round(4)
            phase_path[i+1,:]  =  weight
            angle_path[i+1,:]  =  angle(weight) * 180/ pi
            weight = weight.reshape(1,n)
        #return weight
        R = real(dot(X,conj(weight.T))/abs(weight).sum())#.round(4)
        #final_angle = angle(weight) * 180/pi
        return R#,phase_path,angle_path

def Sumple_sumple2(df,types,period = [42,100,200],guassalpha = 10,L_zero = 2**12,W = 80,L = 0,i_ter = 100):
    '''
    df:输入三个资产的矩阵，合成得到大一统周期
      X_equity,X_bond,X_commodity 三个资产,实际可得数据
    period:[42,100,200]周期三因子
    W:实际数据的长度。窗口期80
    L：滤波时外推的长度
    types:资产分类
    函数实现输入W期的数据并且用外推了L期的数据做合成
    四次调用到sumple_c2
    '''
    res = pd.DataFrame()
    large_asset_factor = pd.DataFrame()
    for p in period:
        #把df滤波。把所有数据都滤波了
        df1 = gauss_filter_c(df,1,p,guassalpha,L_zero,W+L)
        #根据大类划分，分别进行sumple
        for Type in types:
            large_asset_factor[str(Type)] = sumple_c2(df1[:,Type],i_ter).T[0]
        #将三个大类sumple结果，再sumple
        res['p'+str(p)] = sumple_c2(large_asset_factor,i_ter).T[0]
    return res

def cal_n_diff(Xnow,beta,data_all_yoy):
    '''
    根据预测X和系数，计算预测的Y
    '''
    # 3个list
    l=len(beta)
    tmp=[]
    for i in range(1,l+1):
        locals()['predict_%s'%i]=diag(dot(beta[i-1],Xnow))
        #locals()['predict_%s%s'%(i,i)]=diag(dot(beta[i-1],Xpre))
        #locals()['predict_%s'%i]=locals()['predict_%s'%i]-locals()['predict_%s%s'%(i,i)]
        tmp.append(locals()['predict_%s'%i])
    predict_all = pd.DataFrame(np.column_stack((tmp)),
                             index = data_all_yoy.index[-len(tmp[0]):],
                             columns = ['type%s'%(i+1) for i in range(l)]) #index好像有问题？
    return predict_all

def cal_n_lag2(X_now,beta,resYs,data_all_yoy):
    # 3个list
    l=len(beta)
    tmp=[]
    for i in range(1,l+1):
        locals()['predict_%s'%i]=diag(dot(beta[i-1],X_now))+resYs[i-1][:,-1,0]
        #locals()['predict_%s%s'%(i,i)]=diag(dot(beta[i-1],Xpre))
        #locals()['predict_%s'%i]=locals()['predict_%s'%i]-locals()['predict_%s%s'%(i,i)]
        tmp.append(locals()['predict_%s'%i])
    predict_all = pd.DataFrame(np.column_stack((tmp)),
                             index = data_all_yoy.index[-len(tmp[0]):],
                             columns = ['type%s'%(i+1) for i in range(l)]) #index好像有问题？
    return predict_all

def cal_n_lag(X_now,beta,resYs,data_all_yoy):
    '''
    根据预测X和系数，不断预测
    '''
    Res = []
    l = len(beta)
    for i in range(l): # 3
        resY=resYs[i]
        bet=beta[i]
        res=np.array([np.nan]*len(resY))
        # 循环多期
        for t in range(len(resY)):
            X_y=resY[t,-13,:]
            X=X_now[t,-12:,:].sum(axis=1)
            X=np.append(X,X_y)
            #Y=dot(X,bet[])
            '''
            for i in range(12):
                X=X_now[t,-12+i,:]
                #print(X.shape,X_y.shape)
                X=np.append(X,X_y)
                Y=dot(bet[-12+i],X)
                X_y=Y
            '''
            res[t]=Y
        Res.append(res)
    Res = pd.DataFrame(Res,index=['type%s'%i for i in range(l)],
                                  columns=data_all_yoy.index[-len(resY):]).T
    return Res

def array2mat(*arr):
    a=[]
    for ar in arr:
        a.append(np.mat(ar))
    return tuple(a)

def target_func(x,H,f):
    x,H,f=array2mat(x,H,f)
    ans=np.array(0.5*x*H*x.T+f.T*x.T)
    return ans
def ineq_func(x,A,b):
    x,A,b=array2mat(x,A,b)
    try:
        ans=np.array(A*x.T-b).T
    except:
        ans=np.array([0])
    return ans
def eq_func(x,Aeq,beq):
    x,Aeq,beq=array2mat(x,Aeq,beq)
    return np.array(Aeq*x.T-beq).T
def quadprog(H,f,A,b,Aeq,beq,LB,UB):
    H,f,A,b,Aeq,beq=array2mat(H,f,A,b,Aeq,beq)
    bounds=[(x,y) for x,y in zip(LB,UB)]
    #cons=({'type':'ineq','fun':lambda x:ineq_func(x,A=A,b=b)},
    #        {'type':'eq','fun':lambda x:eq_func(x,Aeq=Aeq,beq=beq)})
    cons=({'type':'eq','fun':lambda x:sum(x)-1})
    res=minimize(target_func,x0=[1/len(LB)]*len(LB),bounds=bounds,
                                 constraints=cons,args=(H,f),tol=1e-15)
    return res

def BL_f(ret,Q,BLpara):
    ret_temp=ret
    CovWindow = BLpara.CovWindow
    ConfiWindow = BLpara.ConfiWindow
    Tau = BLpara.Tau
    Lamda = BLpara.Lamda
    delta = BLpara.delta
    c = BLpara.c
    asset_num = ret_temp.shape[1]
    P = np.eye(asset_num)
    Wmarket=ones((asset_num,1))/asset_num
    Hiscov = ret_temp.iloc[-CovWindow:].cov()
    conficov = ret_temp.iloc[-ConfiWindow:].cov()
    OMG_inv = np.linalg.inv(diag(diag(conficov))*c)
    Hiscov,conficov,OMG_inv,Wmarket,P,Q = array2mat(
            Hiscov,conficov,OMG_inv,Wmarket,P,Q)
    Er =((Tau*Hiscov).I+P.T*OMG_inv*P).I*((Tau*Hiscov).I*delta*Hiscov*Wmarket+P.T*OMG_inv*Q.T)
    Covariance = Hiscov +((Tau*Hiscov).I+P.T*OMG_inv*P).I
    Er,Covariance=np.array(Er),np.array(Covariance)
    # 二次规划求解
    res=quadprog(Lamda*Covariance,-Er,None,None,ones((1,asset_num)),1,zeros((asset_num)),ones(asset_num))
    return res

def arr2df(weight_1,*arr):
    idx=weight_1.index
    col=weight_1.columns
    res=[]
    for ar in arr:
        res.append(pd.DataFrame(ar,index=idx,columns=col))
    return tuple(res)

class Strategy():
    def __init__(self,ret,signal,nv=0,delay=0,start_date='2010-06',freq='M'):
        self.ret=ret
        self.signal=signal
        self.delay=delay
        self.start_date=start_date
        self.freq=freq
        if type(nv)==int:
            self.nv_flag=False
            if (signal.sum(axis=1)).any()!=1:
                print('wrong, signal!=1')
        else:
            self.nv=nv
            self.nv_flag=True
    @property
    def Return(self):
        if self.nv_flag:
            return
        self.signal=self.signal.shift(self.delay).dropna()
        q=(self.ret*self.signal).dropna().sum(axis=1)
        q=q[self.start_date:]
        return q
    @property
    def Nv(self):
        try:
            if self.nv_flag:
                self.start_date='2010-05'
                self.nv=self.nv[self.start_date:]
                if len(self.nv)>106:
                    self.nv=self.nv/self.nv.iloc[0]
            return self.nv
        except:
            nv=(self.Return+1).cumprod()
            nv.loc[nv.index[0]-pd.offsets.MonthEnd()]=1
            nv.sort_index(inplace=True)
            self.nv=nv
            return self.nv
    @property
    def Indicator(self):
        data=self.Nv
        df_summary=pd.DataFrame(index=[0])
        net_ret=(data/data.shift(1)-1).dropna()
        total_ret=data.iloc[-1]-1
        if self.freq=='M':
            params=12
        else:
            params=254
        # 输出部分
        df_summary['total_ret']=total_ret
        df_summary['anualized_ret']=((1 + total_ret)**(params / float(len(net_ret)))) -1
        df_summary['anualized_vol']=np.sqrt(net_ret.var() * params)
        df_summary['max_drawdown']=1-data.expanding().apply(lambda x:(x[-1]/(x.max(axis=0))),raw=True).min(axis=0)
        df_summary['sharpe']=df_summary['anualized_ret'].values/df_summary['anualized_vol'].values
        df_summary['calmar']=df_summary['anualized_ret'].values/abs(df_summary['max_drawdown'])
        if self.nv_flag==False:
            #df_summary['盈亏比']=
            #df_summary['胜率']=
            #df_summary['交易次数']
            pass
        return df_summary

def sumple_sumple(df,period = [42,100,200],guassalpha = 10,L_zero = 2**12,W = 120,L = 0,i_ter = 100):
    res = []
    for p in period:
        #把df滤波。把所有数据都滤波了
        df1=df.copy()#.iloc[-W:]
        df1[:]=gauss_filter_c(df,1,p,guassalpha,L_zero,W+L)
        res.append(df1)
    # 转化成12个的list，每个元素是一个3因子df
    asset_factor=[pd.concat([res[0][i],res[1][i],res[2][i]],axis=1) for i in df.columns]
    #for i in range(len(asset_factor)):
    #    asset_factor[i].columns=['period'+str(i) for i in period]
    return asset_factor

def cal_n_each(Xnow,beta,data_all_yoy):
    # 做各自周期三因子的使用版本
    if len(beta)!=len(Xnow):
        print('wrong size of Xnow and beta')
        return
    l=len(beta)
    tmp=[diag(dot(beta[i],Xnow[i].T)) for i in range(l)]
    predict_all = pd.DataFrame(np.column_stack((tmp)),
                             index = data_all_yoy.index[-len(tmp[0]):],
                             columns = ['type%s'%(i+1) for i in range(l)]) #index好像有问题？
    return predict_all


def get_3factors_each_asset(data_all_yoy,GFpara,types,predict=False):
    # 获取每个资产的三因子
    W,period,guassalpha=GFpara.W,GFpara.period,GFpara.guassalpha
    resX = []
    for i in range(W,len(data_all_yoy)):
        #idx = data_all_yoy.iloc[i].name
        idx = i
        try:
            # 计算每段X滤波的结果
            tmp = data_all_yoy.iloc[i-W:i] #不包括第i+W期
            resX.append(sumple_sumple(tmp,period = period,guassalpha = guassalpha,
                W = W))
        except:
            print('wrong in %s'%i)
            pass
    #resX是n期，每期12个list的list，转化成12个资产的list
    resX_trans=[np.array([x[i].values for x in resX]) for i in range(len(resX[0]))]
    if predict:
        idx+=1
        tmp = data_all_yoy.iloc[-W:]
        resX[idx] = sumple_sumple(tmp,period = period,guassalpha = guassalpha,
            W = W)
    return resX_trans

def get_3factors_n_largeasset_filter(data_all_yoy,types,GFpara,
                                     predict=False,includeX=True,show_df=False):
    # 在每个时刻，对过去一段窗口期内的数据进行滤波提取三因子，然后再对自己也进行滤波。然后回归
    # 返回值变成array
    flag3=False
    W,period,guassalpha=GFpara.W,GFpara.period,GFpara.guassalpha
    resX,resY1,resY2,resY3  =  [],[],[],[]
    resY4,resY5 = [],[] # 新增
    for i in range(W,len(data_all_yoy)):
        # 计算每段X滤波的结果
        tmp = data_all_yoy.iloc[i-W:i] #不包括第i期
        if includeX:
            resX.append( Sumple_sumple2(tmp,types,period = period,guassalpha = guassalpha,
                W = W))
        resY1.append( sumple_c2(tmp.iloc[:,types[0]]))
        resY2.append( sumple_c2(tmp.iloc[:,types[1]]))
        try:
            types[2]
            resY3.append( sumple_c2(tmp.iloc[:,types[2]]))
        except:
            flag3=True


    '''
    # 这部分是不删除最后一个预测值，用于现实中得到最新的预测
    if predict:
        idx+=1
        tmp = data_all_yoy.iloc[-W:]
        resX[idx] = Sumple_sumple2(tmp,types,period = period,guassalpha = guassalpha,
            W = W)
        resY1[idx] = sumple_c2(tmp.iloc[:,types[0]])
        resY2[idx] = sumple_c2(tmp.iloc[:,types[1]])
        resY3[idx] = sumple_c2(tmp.iloc[:,types[2]])
    '''
    if show_df: #展示dataframe版本
        pass
    resY1=np.array(resY1)
    resY2=np.array(resY2)
    try:
        resY3=np.array(resY3)
    except:
        pass
    # 新增结束
    if includeX:
        restmp=[x.values for x in resX]
        resX=np.array(restmp)
        if flag3:
            return resX,resY1,resY2
        else:
            return resX,resY1,resY2,resY3#,resY4,resY5
    else:
        return resY1,resY2,resY3,resY4,resY5

def get_3factors_for_largeasts(data_all_yoy,types,GFpara,predict=False):
    # 使用各自的周期三因子版本的
    # 在每个时刻，对过去一段窗口期内的数据进行滤波提取三因子，并合成
    W,period,guassalpha=GFpara.W,GFpara.period,GFpara.guassalpha
    resY1,resY2,resY3,resY4,resY5  =  [],[],[],[],[]
    for i in range(W,len(data_all_yoy)):
        #idx = data_all_yoy.iloc[i].name
        idx = i
        try:
            # 计算每段X滤波的结果
            tmp = data_all_yoy.iloc[i-W:i] #不包括第i期
            resY1.append( Sumple_sumple2(tmp,[types[0]],period = period,guassalpha = guassalpha,
                W = W).values)
            resY2.append( Sumple_sumple2(tmp,[types[1]],period = period,guassalpha = guassalpha,
                W = W).values)
            resY3.append( Sumple_sumple2(tmp,[types[2]],period = period,guassalpha = guassalpha,
                W = W).values)
            resY4.append( Sumple_sumple2(tmp,[types[3]],period = period,guassalpha = guassalpha,
                W = W).values)
            resY5.append( Sumple_sumple2(tmp,[types[4]],period = period,guassalpha = guassalpha,
                W = W).values)
        except:
            pass
    resY1=np.array(resY1)
    resY2=np.array(resY2)
    resY3=np.array(resY3)
    resY4=np.array(resY4)
    resY5=np.array(resY5)
    if predict:
        idx+=1
        tmp = data_all_yoy.iloc[-W:]
        resY1[idx] = sumple_c2(tmp.iloc[:,types[0]])
        resY2[idx] = sumple_c2(tmp.iloc[:,types[1]])
        resY3[idx] = sumple_c2(tmp.iloc[:,types[2]])
    return resY1,resY2,resY3,resY4,resY5

def get_3factors_for_largeasts_self(data_all_yoy,types,GFpara,predict=False):
    # 使用各自的周期三因子版本的
    # 在每个时刻，对过去一段窗口期内的数据进行滤波提取三因子，并合成
    W,period,guassalpha=GFpara.W,GFpara.period,GFpara.guassalpha
    period=[[42,23,30],[41,27,23],[41,73,315]]
    resY1,resY2,resY3  =  [],[],[]#{},{},{}
    for i in range(W,len(data_all_yoy)):
        #idx = data_all_yoy.iloc[i].name
        idx = i
        try:
            # 计算每段X滤波的结果
            tmp = data_all_yoy.iloc[i-W:i] #不包括第i期
            resY1.append( Sumple_sumple2(tmp,[types[0]],period = period[0],guassalpha = guassalpha,
                W = W).values)
            resY2.append( Sumple_sumple2(tmp,[types[1]],period = period[1],guassalpha = guassalpha,
                W = W).values)
            resY3.append( Sumple_sumple2(tmp,[types[2]],period = period[2],guassalpha = guassalpha,
                W = W).values)
        except:
            pass
    resY1=np.array(resY1)
    resY2=np.array(resY2)
    resY3=np.array(resY3)
    if predict:
        idx+=1
        tmp = data_all_yoy.iloc[-W:]
        resY1[idx] = sumple_c2(tmp.iloc[:,types[0]])
        resY2[idx] = sumple_c2(tmp.iloc[:,types[1]])
        resY3[idx] = sumple_c2(tmp.iloc[:,types[2]])
    return resY1,resY2,resY3


def filter_predict(resX,GFpara,predict_len=12):
    # resX是一个3维的array
    # 对滤波的结果再次滤波
    W,period,alpha=GFpara.W,GFpara.period,GFpara.guassalpha
    shp=list(resX.shape)
    shp[1]+=predict_len
    x_predict = zeros(shp)
    for idx in range(resX.shape[0]):
        tmp=[]
        xtmp=resX[idx,:,:]
        tmp = []
        for i in range(3):
            tmp.append(gauss_filter_c(xtmp[:,i],period = period[i],guassalfa=alpha,L = W+predict_len))
        #tmp2 = pd.DataFrame(np.column_stack(tmp),columns = ['period%s'%p for p in period])
        tmp2=np.column_stack(tmp)
        x_predict[idx] = tmp2
    # 整合X值成矩阵
    X_now = np.vstack([x[-1:] for x in x_predict])
    X_pre = np.vstack([x[-2:-1] for x in x_predict])
    # 补上常数项
    X_now = add_constant(X_now).T
    X_pre = add_constant(X_pre).T
    return X_now,X_pre

def filter_predict_2(resX,GFpara):
    # resX是一个3维的array
    # 对滤波的结果再次滤波
    # n是外推期数
    W,period,alpha=GFpara.W,GFpara.period,GFpara.guassalpha
    shp=list(resX.shape)
    #shp[2]+=1
    shp[1]+=12
    x_predict = zeros(shp)
    for idx in range(resX.shape[0]):
        tmp=[]
        xtmp=resX[idx,:,:]
        tmp = []
        for i in range(3):
            tmp.append(gauss_filter_c(xtmp[:,i],period = period[i],guassalfa=alpha,L = W+12))
        #tmp2 = pd.DataFrame(np.column_stack(tmp),columns = ['period%s'%p for p in period])
        tmp2=np.column_stack(tmp)
        x_predict[idx] = tmp2
    # 整合X值成矩阵
    #X_now = np.hstack([x[-12:,:] for x in x_predict])
    X_now = x_predict[:,-1,:] - x_predict[:,-13,:]
    #X_pre = np.vstack([x[-2:-1] for x in x_predict])
    # 补上常数项
    #X_now = add_constant(X_now).T
    #X_pre = add_constant(X_pre).T
    return X_now#,X_pre

def frequency_spectrum(X,Fs,n=1,shot_plot=True):
    if len(X.shape)==2:
        m,n=X.shape
    else:
        n=X.shape[0]
    Y=np.fft.fft(X).T # 转置了
    Spectrum_all=abs(Y/n)
    Spectrum_single=Spectrum_all[:int(n/2)+1]
    Spectrum_single[1:-1]*=2
    # 计算频率(x轴)
    freq_x=Fs*np.arange(int(n/2)+1)/n
    # 找极值转成最大值
    local_max_idx=sc.signal.argrelextrema(Spectrum_single,np.greater)[0]
    max_y=Spectrum_single[local_max_idx]
    max_topN=sorted(max_y)[-n]
    max_idx=local_max_idx[max_y>=max_topN]

    if shot_plot:
        f=plt.figure()
        ax1=f.add_subplot(2,1,1)
        ax2=f.add_subplot(2,1,2)
        if isinstance(X,pd.DataFrame):
            X.plot(ax=ax1)
        else:
            ax1.plot(X)
        ax2.plot(freq_x,Spectrum_single)
        ax2.scatter(freq_x,Spectrum_single,
                    marker='s',color='k')
        for idx in max_idx:
            x,y=freq_x[idx],Spectrum_single[idx]
            plt.text(x,y,'freq=%s;value=%s'%(x,y))
        ax1.set_title('时域序列')
        ax2.set_title('频率序列')

    return
'''
def frequency_spectrum(df,L_zero=2**12,n=5,detrend=False,show=False):
    df1=copy.deepcopy(df)
    if detrend:
        const=np.ones(len(df1))
        t=np.arange(len(df1))
        xx=np.column_stack((const,t))
        res=OLS(df,xx).fit()
        df1=df1-t*res.params.iloc[1]
    df_wave=abs(fftshift(sc.fft(df1,L_zero)))
    freq_index=(np.arange(L_zero/2+1.)/L_zero).reshape((int(L_zero/2+1),1))
    freq_index2=(np.arange(-L_zero/2+1,0)/L_zero).reshape((int(L_zero/2-1),1))
    freq_index=np.vstack((freq_index,freq_index2))
    freq_index=fftshift(freq_index).T[0]
    if show:
        plt.plot(freq_index[int(L_zero/2):],df_wave[int(L_zero/2):])
    max_idx=sc.signal.argrelextrema(df_wave[int(L_zero/2):],np.greater)[0]
    max_y=df_wave[int(L_zero/2):][max_idx]
    max_topN=sorted(max_y)[-n]
    max_idx=max_idx[max_y>=max_topN]
    max_y=df_wave[int(L_zero/2):][max_idx]
    max_x=freq_index[int(L_zero/2):][max_idx]
    max_scatter=[(1/a,b) for a,b in zip(max_x,max_y)]
    if show:
        for a,b in max_scatter:
            plt.text(1/a,b,'%s,%s'%(a.round(2),b.round(2)))
    max_scatter=pd.DataFrame(max_scatter,columns=['周期','峰值'])
    max_scatter.sort_values('峰值',ascending=False,inplace=True)
    return max_scatter
'''

def filter_predict_each(resX,GFpara):
    # 对滤波的结果再次滤波
    W,period,alpha=GFpara.W,GFpara.period,GFpara.guassalpha
    x_predict = copy.deepcopy(resX)
    for idx in range(len(resX)):
        x=resX[idx]
        shp=list(x.shape)
        shp[1]+=12
        tmp3=zeros(shp)
        for i in range(x.shape[0]):
            xtmp=x[i,:,:]
            tmp=[]
            for j in range(3):
                tmp.append(gauss_filter_c(xtmp[:,j],period = period[j],guassalfa=alpha,L = W+12))
            tmp2 = np.column_stack(tmp)
            tmp3[i] = tmp2
        x_predict[idx] = tmp3
    # 整合X值成矩阵
    X_now_list=[add_constant(np.array([x_1[-1,:] for x_1 in x])) for x in x_predict]
    # 加入滞后项

    return X_now_list#,X_pre

def filter_predict_rolling(resX,GFpara):
    # 对滤波的结果再次滤波
    W,period,alpha=GFpara.W,GFpara.period,GFpara.guassalpha
    x_predict = copy.deepcopy(resX)
    for idx,xtmp in resX.items():
        if type(xtmp) == float:
            x_predict[idx] = np.nan
        else:
            tmp = []
            for i in range(3):
                tmp.append(gauss_filter_c(xtmp.iloc[:,i],period = period[i],guassalfa=alpha,L = W+24))
            tmp2 = pd.DataFrame(np.column_stack(tmp),columns = ['p42','p100','p200'])
            x_predict[idx] = tmp2
    # 整合X值成矩阵
    x_output={idx:add_constant(x.iloc[-24:]) for idx,x in x_predict.items() if type(x)!=float}
    return x_output

def prepare_work(data_all_price,types):
    '''
    准备月度收益率，大类资产表现
    '''
    ret=data_all_price.pct_change()
    ret_each=data_all_price.pct_change()
    tmp=pd.DataFrame(index=data_all_price.index)
    tmp['stock']=ret_each.iloc[:,types[0]].mean(axis=1)
    tmp['bond']=ret_each.iloc[:,types[1]].mean(axis=1)
    tmp['commodity']=ret_each.iloc[:,types[2]]
    #tmp['利差']=ret_each.iloc[:,types[3]]
    #tmp['房地产']=ret_each.iloc[:,types[4]]
    tmps=(tmp['2010-05':]+1).cumprod()
    tmps=tmps/tmps.iloc[0]
    a1=Strategy(ret=1,signal=1,nv=tmps.stock).Indicator
    a2=Strategy(ret=1,signal=1,nv=tmps.bond).Indicator
    a3=Strategy(ret=1,signal=1,nv=tmps.commodity).Indicator
    #a4=Strategy(ret=1,signal=1,nv=tmps.利差).Indicator
    #a5=Strategy(ret=1,signal=1,nv=tmps.房地产).Indicator
    aa=pd.concat([a1,a2,a3])
    aa.index=['stock','bond','commodity']#,'利差','房地产']
    return ret,aa,tmps,tmp

def cal_Beta(resX,*resY):#,resY4,resY5):
    res = []
    res_p=[]
    #nm=['stock','bond','comm','ratedif','fdc']
    n=-1
    for y in resY:
        n+=1
        resAssets = []
        res_pv=[]
        #writer=pd.ExcelWriter('Beta_%s.xlsx'%nm[n])
        for i in range(resX.shape[0]):
            x=add_constant(resX[i,:,:])
            #x=add_constant(np.diff(resX[i,:,:],axis=0))
            #x=np.column_stack((x,y[i,:-1,0])) #加入y一阶滞后

            ols_res=OLS(y[i,:,0],x,missing = 'drop').fit()
            #resid=pd.Series(ols_res.resid)
            #resid.to_excel(writer,str(i))
            # 加入不显著，就把系数=0
            coef=ols_res.params
            #coef[ols_res.pvalues>0.05]=0.
            resAssets.append(coef)
            #res_pv.append(np.column_stack((ols_res.predict(x),y[i,:,0]))) #暂时改成输出y和y_hat
            res_pv.append(ols_res.resid)
        #writer.save()
        res.append(resAssets)
        res_p.append(res_pv)

    container=np.array(res)
    res_p=np.array(res_p)
    #for i in range(1,len(res)+1):
    #    locals()['Beta_'+str(i)] = np.vstack([x for x in res[i-1]])
    #    container.append(locals()['Beta_'+str(i)])
    return container,res_p

def cal_Beta_dif(resX,*resY):#,resY4,resY5):
    res = []
    res_p=[]
    #nm=['stock','bond','comm','ratedif','fdc']
    n=-1
    for y in resY:
        n+=1
        resAssets = []
        res_pv=[]
        for i in range(resX.shape[0]):
            x=np.diff(resX[i,:,:],axis=0)

            ols_res=OLS(np.diff(y[i,:,0]),x,missing = 'drop').fit()
            #resid=pd.Series(ols_res.resid)
            #resid.to_excel(writer,str(i))
            resAssets.append(ols_res.params)
            #res_pv.append(np.column_stack((ols_res.predict(x),y[i,:,0]))) #暂时改成输出y和y_hat
            res_pv.append(ols_res.pvalues)
        #writer.save()
        res.append(resAssets)
        res_p.append(res_pv)

    container=np.array(res)
    res_p=np.array(res_p)
    #for i in range(1,len(res)+1):
    #    locals()['Beta_'+str(i)] = np.vstack([x for x in res[i-1]])
    #    container.append(locals()['Beta_'+str(i)])
    return container,res_p

'''
def cal_Betas(resX,resY1,resY2,resY3):
    res = []
    for y in [resY1,resY2,resY3]:
        resAssets = {}
        for k,x in resX.items():
            if type(x) == float:
                pass
                #resAssets[k] = np.nan
            else:
               resAssets[k] = OLS(y[k],add_constant(x),missing = 'drop').fit().params.values
        res.append(resAssets)
    # 用矩阵计算。每个系数矩阵代表一列大类资产的预测
    container=[]
    for i in range(1,len(res)+1):
        locals()['Beta_'+str(i)] = np.vstack([x for x in res[i-1].values() if type(x)!=float])
        container.append(locals()['Beta_'+str(i)])
    return tuple(container)
'''
def cal_beta_each(data_all_yoy,resX,W,resY123,resX123):
    # 计算12个子类和3大类，用自身的三因子回归的结果
    res_small = []
    for i in range(data_all_yoy.shape[1]):
        y=data_all_yoy.iloc[:-1].iloc[:,i]
        x=resX[i]
        resAssets = []
        for j in range(x.shape[0]):
            x1=x[j,:,:]
            resAssets.append(OLS(y.iloc[j:j+W].values,add_constant(x1),
                    missing = 'drop').fit().params)
        res_small.append(np.array(resAssets))
    for y1,x1 in zip(resY123,resX123):
        resAssets = []
        for k in range(x1.shape[0]):
            y=y1[k,:,0]
            x=x1[k,:,:]
            resAssets.append( OLS(y,add_constant(x),missing = 'drop').fit().params)
        res_small.append(np.array(resAssets))
    # 用矩阵计算。每个系数矩阵代表一列大类资产的预测
    #tmp=[]
    #for i in range(1,len(res_small)+1):
    #    locals()['beta_'+str(i)] = np.vstack([x for x in res_small[i-1]])
    #    tmp.append(locals()['beta_'+str(i)])
    return res_small

def cal_beta(data_all_yoy,resX,W):
    # 子类资产回归
    res_small = []
    for idx in range(data_all_yoy.shape[1]): # iter每个资产
        #writer=pd.ExcelWriter('beta_%s.xlsx'%data_all_yoy.columns[idx][:4])
        y=data_all_yoy.iloc[:-1,idx]
        resAssets = []
        for i in range(resX.shape[0]): # iter窗口
            x=resX[i,:,:]
            fit_res=OLS(y.iloc[i:i+W].values,add_constant(x),
                     missing = 'drop').fit()
            resAssets.append( fit_res.params)
            #fit_res.resid.to_excel(writer,str(i))
        #writer.save()
        res_small.append(np.array(resAssets))
    # 用矩阵计算。每个系数矩阵代表一列大类资产的预测
    #tmp=[]
    #for i in range(1,len(res_small)+1):
    #    locals()['beta_'+str(i)] = np.vstack([x for x in res_small[i-1].values() if type(x)!=float])
    #    tmp.append(locals()['beta_'+str(i)])
    return tuple(res_small)
def cal_beta_dif(data_all_yoy,resX,W):
    # 子类资产回归
    res_small = []
    for idx in range(data_all_yoy.shape[1]): # iter每个资产
        #writer=pd.ExcelWriter('beta_%s.xlsx'%data_all_yoy.columns[idx][:4])
        y=data_all_yoy.iloc[:-1,idx]
        resAssets = []
        for i in range(resX.shape[0]): # iter窗口
            x=resX[i,:,:]
            fit_res=OLS(y.iloc[i:i+W].diff().values,add_constant(np.diff(x)),
                     missing = 'drop').fit()
            resAssets.append( fit_res.params)
            #fit_res.resid.to_excel(writer,str(i))
        #writer.save()
        res_small.append(np.array(resAssets))
    # 用矩阵计算。每个系数矩阵代表一列大类资产的预测
    #tmp=[]
    #for i in range(1,len(res_small)+1):
    #    locals()['beta_'+str(i)] = np.vstack([x for x in res_small[i-1].values() if type(x)!=float])
    #    tmp.append(locals()['beta_'+str(i)])
    return tuple(res_small)

def cal_R_square(data_all_yoy,resX,W):
    # 子类资产回归
    res_small = []
    for idx in data_all_yoy:
        y=data_all_yoy.iloc[:-1][idx]
        resAssets = {}
        for k,x in resX.items():
            if type(x) == float:
                pass
                #resAssets[k] = np.nan
            else:
               resAssets[k] = OLS(y.iloc[k-W:k].values,add_constant(x),
                        missing = 'drop').fit().rsquared
        res_small.append(resAssets)
    res_small=pd.DataFrame(res_small,index=data_all_yoy.columns).T
    res_small.index=data_all_yoy.index[-111:]
    return res_small

def risk_budget_model_root(cov,budget,tps):
    x0=np.array(budget)/sqrt(diag(cov))
    x0=np.insert(x0,-1,0)
    res1=root(cal_riskRatio,x0,args=(cov,budget,tps),tol=1e-10)
    res=res1.x[:-1]
    rescheck=cal_riskRatio_check(res,cov,budget)[0]
    if (res<0).any() or abs(res.sum()-1)>1e-4:
        x0=np.array(budget)/sqrt(diag(cov))
        #如果没有正数解，就进行最小化优化
        cons=({'type':'eq','fun':lambda x:x.sum()-1})
        res1=minimize(cal_riskRatio,x0,args=(cov,budget,2),
                         bounds=[(0,1)]*cov.shape[0],
                         constraints=cons,tol=1e-10,
                         method='Powell',
                         options={'maxiter':200})
        res=res1.x
    res=res/res.sum()
    rescheck=cal_riskRatio_check(res,cov,budget)[0]

    return res,rescheck,res1

def cal_riskRatio(X,cov,budget,tps):
    # 输入协方差矩阵，计算风险平价
    if tps==1:
        x=X[:-1]
    else:
        x=X
    w=np.mat(x).T
    covM=np.matrix(cov)
    sigmaP=w.T*covM*w #这里除以常数不影响结果，就不计算了
    #print(np.diag(x).shape,covM.shape,w.shape)
    tmp=np.diag(x)*(covM*w) #这里直接矩阵运算得到一个n*1的向量
    res=np.array(tmp).T[0]/np.array(sigmaP) #[0]从矩阵降成向量
    #print(res.shape)
    res=(res-np.array(budget))[0]
    #print(res.shape)
    if tps==1:
        output=(res-res.mean())
        output=np.append(output,sum(x)-1)
    else:
        output=sum((res-res.mean())**2)*10000
    return output
def cal_riskRatio_check(x,cov,budget):
    # 输入协方差矩阵，计算风险平价
    w=np.mat(x).T
    covM=np.matrix(cov)
    sigmaP=w.T*covM*w #这里除以常数不影响结果，就不计算了
    tmp=np.diag(x)*(covM*w) #这里直接矩阵运算得到一个n*1的向量
    res=np.array(tmp).T[0]/np.array(sigmaP) #[0]从矩阵降成向量
    #res_adjust=res/np.array(budget)
    res_adjust=res-np.array(budget)
    return res_adjust

